public interface Simulatable {

    void prepare(int number_of_turn);

    void update(int current_turn);
}
