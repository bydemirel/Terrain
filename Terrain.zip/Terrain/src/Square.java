
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Square {
    int number_of_gold = new Random().nextInt(11);
    Monster monster;
    List<Hero> heroes;
    Position position;

    public Square(Monster monster,Position position) {
        this.monster = monster;
        this.position = position;
        this.heroes = new ArrayList<>();
    }

    public void removeMonster(){
        this.monster=null;
    }

    public void removeHero(Hero hero){
        hero = null;
    }
    public String toString() {
        String st="";
        if(heroes.size()>0&&monster!=null)
        return "["+heroes+"vs"+monster+"]("+number_of_gold+")";
        if(monster==null&&heroes.size()==0)
            return "("+number_of_gold+")";
        if(monster!=null&&heroes.size()==0)
            return "["+monster+"]("+number_of_gold+")";
        if(heroes.size()>0&&monster==null)
            return "["+heroes+"]("+number_of_gold+")";


        return st;

    }
}
