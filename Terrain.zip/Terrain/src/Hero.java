import java.util.Random;

public class Hero {
    String name;
    int health = new Random().nextInt(100)+1;
    int wallet;
    Position position;

    public Hero(String name,Position position) {
        this.name = name;
        this.position=position;
        this.wallet = 0;
    }

    public boolean isAlive(){
        return health>0;
    }

    public void addGoldToWallet(int number_of_gold){
        wallet+=number_of_gold;
    }

    public String toString(){
        return name;
    }

}
