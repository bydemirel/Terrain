import sun.misc.Cleaner;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Terrain implements Simulatable {
    Square terrain[][];
    List<Hero> heroes;
    List<Monster> monsters;
    int number_of_turn;
    int terrain_row_size;
    int terrain_col_size;

    public Terrain(List<Hero> heroes, List<Monster> monsters, int number_of_turn, int terrain_row_size, int terrain_col_size) {
        this.terrain = new Square[terrain_row_size][terrain_col_size];
        this.heroes = heroes;
        this.monsters = monsters;
        this.number_of_turn = number_of_turn;
        this.terrain_row_size = terrain_row_size;
        this.terrain_col_size = terrain_col_size;
    }

    public void game() {
        prepare(number_of_turn);

        int current_turn = 1;
        while (current_turn <= number_of_turn) {
            bekle();
            System.out.print("\n" + "TURN ==> " + current_turn);
            toString();
            bekle();
            System.out.print("\n\n"+"  ***************INFORMATION PANEL***************");
            update(current_turn);
            System.out.println("\n*********************************************************************************");
            PrintMonsters();
            current_turn++;
        }

    }

    private void bekle() {
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void PrintMonsters() {
        for (int row = 0; row < terrain_row_size; row++) {
            for (int col = 0; col < terrain_col_size; col++) {
                if(terrain[row][col].monster!=null)
                    System.out.println(terrain[row][col].monster+" : "+terrain[row][col].position+" Damage : "+terrain[row][col].monster.damage);
            }
        }
    }


    @Override
    public void prepare(int number_of_turn) {
        setTerrain();
        putMonsters();
        putHeroes();
    }

    private void setTerrain() {
        for (int row = 0; row < terrain_row_size; row++) {
            for (int col = 0; col < terrain_col_size; col++) {
                terrain[row][col] = new Square(null, new Position(row,col));
            }
        }
    }

    private void putHeroes() {
        for (int i = 0; i < heroes.size(); i++) {
            int random_row = new Random().nextInt(terrain_row_size);
            int random_col = new Random().nextInt(terrain_col_size);

            for (int row = 0; row < terrain_row_size; row++) {
                for (int col = 0; col < terrain_col_size; col++) {
                    if (random_row == row && random_col == col && heroes.get(i).health>0) {
                        heroes.get(i).position.row = random_row;
                        heroes.get(i).position.col = random_col;
                        terrain[row][col].heroes.add(heroes.get(i));
                    }
                }
            }

        }
    }


    private void putMonsters() {
        for (int i = 0; i < monsters.size(); i++) {
            int random_row = new Random().nextInt(terrain_row_size);
            int random_col = new Random().nextInt(terrain_col_size);
            for (int row = 0; row < terrain_row_size; row++) {
                for (int col = 0; col < terrain_col_size; col++) {
                    if (random_row == row && random_col == col)
                        terrain[row][col] = new Square(monsters.get(i), new Position(row, col));
                }
            }
        }
    }

    @Override
    public void update(int current_turn) {


        checkGold();
        checkFight();

        for (int i = 0; i < heroes.size(); i++) {
            System.out.print("\n"+heroes.get(i)+" : HP : "+heroes.get(i).health+" Positon : "+heroes.get(i).position+" Collected Gold : ("+heroes.get(i).wallet+")");

            move(heroes.get(i));


        }
    }

    private void checkGold() {
        for (int row = 0; row < terrain_row_size; row++) {
            for (int col = 0; col < terrain_col_size; col++) {
                if (terrain[row][col].heroes.size() > 0)
                    collectGold(terrain[row][col], terrain[row][col].heroes);
            }
        }
    }

    private void collectGold(Square square, List<Hero> hero_list) {
        int max_health = 0;
        int strongest_hero_index = 0;
        for (int i = 0; i < hero_list.size(); i++) {
            if(hero_list.get(i).health>max_health){
                max_health = hero_list.get(i).health;
                strongest_hero_index = i;
            }

        }
        hero_list.get(strongest_hero_index).addGoldToWallet(square.number_of_gold);
        square.number_of_gold = 0;
    }

    private void fight(Monster monster, List<Hero> hero_list) {
        int max_health = 0;
        int fighter_index = -1;
        for (int i = 0; i < hero_list.size(); i++) {
            if (hero_list.get(i).health > max_health) {
                max_health = hero_list.get(i).health;
                fighter_index = i;
            }

        }
        if (hero_list.get(fighter_index).health > monster.damage) {
            printFightHeroWin(monster,hero_list.get(fighter_index));
            hero_list.get(fighter_index).health -= monster.damage;
            terrain[hero_list.get(fighter_index).position.row][hero_list.get(fighter_index).position.col].removeMonster();
        }
        else {
            printFightHeroLost(monster,hero_list.get(fighter_index));
            hero_list.get(fighter_index).wallet = 0;
            heroes.remove(hero_list.get(fighter_index));
            hero_list.remove(fighter_index);
            terrain[hero_list.get(fighter_index).position.row][hero_list.get(fighter_index).position.col].removeMonster();


        }
    }

    private void printFightHeroWin(Monster monster, Hero hero) {
        System.out.println(String.format("%-15s","\n !!!!!!!!!!!FIGHT!!!!!!!!!!!"));
        System.out.println(String.format("%-15s","           "+hero+"VS"+monster));
        System.out.println(String.format("%-15s","**********HERO WIN**********"));
    }


    private void printFightHeroLost(Monster monster, Hero hero) {
        System.out.println(String.format("%-15s","\n !!!!!!!!!!!FIGHT!!!!!!!!!!!"));
        System.out.println(String.format("%-15s","           "+hero+"VS"+monster));
        System.out.println(String.format("%-15s","**********HERO WIN**********"));
    }

    private void checkFight() {
        for (int row = 0; row < terrain_row_size; row++) {
            for (int col = 0; col < terrain_col_size; col++) {
                if (terrain[row][col].monster != null && terrain[row][col].heroes.size() > 0)
                    fight(terrain[row][col].monster, terrain[row][col].heroes);
            }
        }
    }

    private void move(Hero hero) {
        int r = new Random().nextInt(4);

        if(r==0 && hero.position.row-1>=0){
            hero.position.row--;
            terrain[hero.position.row+1][hero.position.col].heroes.remove(hero);
            terrain[hero.position.row][hero.position.col].heroes.add(hero);
        }

        if(r==1 && hero.position.row+1<terrain_row_size){
            hero.position.row++;
            terrain[hero.position.row-1][hero.position.col].heroes.remove(hero);
            terrain[hero.position.row][hero.position.col].heroes.add(hero);
        }

        if(r==2 && hero.position.col-1>=0){
            hero.position.col--;
            terrain[hero.position.row][hero.position.col+1].heroes.remove(hero);
            terrain[hero.position.row][hero.position.col].heroes.add(hero);
        }

        if(r==3 && hero.position.col+1<terrain_col_size){
            hero.position.col++;
            terrain[hero.position.row][hero.position.col-1].heroes.remove(hero);
            terrain[hero.position.row][hero.position.col].heroes.add(hero);
        }

    }

    public String toString() {
        String st = "";
        for (int row = 0; row < terrain_row_size; row++) {
            System.out.println();
            for (int col = 0; col < terrain_col_size; col++) {
                System.out.print(String.format("|%-15s|",terrain[row][col]));
            }

        }

        return st;
    }

    public static void main(String[] args) {
        int NUMBER_OF_TURN = 50;
        List<Hero> heroes = new ArrayList<>();
        List<Monster> monsters = new ArrayList<>();
        Hero H1 = new Hero("H1", new Position(0, 0));//If you want, you can give suitable position to Hero or if you don't change anything program will give position to Hero randomly
        Hero H2 = new Hero("H2", new Position(0,0));
        Hero H3 = new Hero("H3", new Position(0,0));
        heroes.add(H1);
        heroes.add(H2);
        heroes.add(H3);
        Monster M1 = new Monster("M1");
        Monster M2 = new Monster("M2");
        Monster M3 = new Monster("M3");
        monsters.add(M1);
        monsters.add(M2);
        monsters.add(M3);
        Terrain T = new Terrain(heroes, monsters, NUMBER_OF_TURN, 8, 6);
        T.game();

    }

}
