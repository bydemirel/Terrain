import java.util.Random;

public class Monster {
    String name;
    int damage = new Random().nextInt(10)+1;

    public Monster(String name) {
        this.name = name;
    }

    public void attack(Hero hero){
        hero.health-=damage;
    }

    public String toString(){
        return name;
    }

}
